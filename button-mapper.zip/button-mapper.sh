#!/bin/bash
# PORTMASTER LAUNCHER - BUTTON-MAPPER (GODOT)

controlfolder="/roms/ports"
source $controlfolder/control.txt
get_controls

GAMEDIR="/roms/ports/button-mapper"

# Set SDL controller config from PortMaster
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# Optional but often required for Godot
export SDL_JOYSTICK_HIDAPI=0
export SDL_VIDEO_X11_DGAMOUSE=0

# Ensure executable permission
chmod +x "$GAMEDIR/button-mapper.x86_64"

cd "$GAMEDIR"

./button-mapper.x86_64

exit 0

